package com.pratice.myfirstjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfirstjavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
