package com.pratice.myfirstjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfirstjavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfirstjavaApplication.class, args);
	}

}
